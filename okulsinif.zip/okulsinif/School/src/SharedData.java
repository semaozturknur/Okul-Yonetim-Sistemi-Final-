import java.util.ArrayList;
import java.util.List;

public class SharedData {
    public static List<String> dersListesi = new ArrayList<>();
}
